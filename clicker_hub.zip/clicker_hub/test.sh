#!/bin/sh

TOKEN=6238521327:AAEeyq2A9jNnCYuNmiGTi0RCzEvABD0aavI
CHAT_ID=1443756312

MESSAGE="$@"

curl -m 3 -X POST -H "Content-Type:multipart/form-data" -F chat_id=$CHAT_ID -F text="$MESSAGE" "http://localhost:8000/bot$TOKEN/sendMessage" 1>/dev/null 2>/dev/null &
