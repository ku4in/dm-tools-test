#!/bin/bash

read -p "Client id: " client_id
IFS=',' read -a books    -p "Input books IDs: "
IFS=',' read -a amounts  -p "Input amounts: "

len_b=${#books[@]}
len_a=${#amounts[@]}
min=$(( len_b > len_a ? len_a : len_b ))

N=$((min - 1))
# echo $min
echo "INSERT OR REPLACE INTO test VALUES $(for i in $(seq 0 $N ); do echo -n \($client_id, ${books[$i]}, ${amounts[$i]}\); if [ "$i" -ne "$N" ]; then echo ,; fi; done);"

# create table test (client_id integer not null, book_id integer not null, init_amount not null default 0, unique (client_id, book_id) );
# 
# sqlite> insert into test values (1, 2, 10); 
# sqlite> select * from test;
# 1|2|10
# sqlite> insert into test values (1, 2, 11); 
# Error: UNIQUE constraint failed: test.client_id, test.book_id
# sqlite> 
# sqlite> insert into test values (1, 3, 11); 
# sqlite> select * from test;
# 1|2|10
# 1|3|11
# sqlite> insert or replace into test values (1, 2, 33); 
# sqlite> select * from test;
# 1|3|11
# 1|2|33
# sqlite>
