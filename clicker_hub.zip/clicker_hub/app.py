#!/usr/bin/env python3

import os
import sqlite3
from threading import Thread
from flask import Flask, render_template, request, g

DATABASE = 'clients.db'

from dotenv import load_dotenv
load_dotenv()

app = Flask(__name__)


class TG_info(Thread):
    def __init__(self, hub_id, ep_id, book_id, amount, note):
        super().__init__()
        self.hub_id  = hub_id
        self.ep_id   = ep_id
        self.book_id = book_id
        self.amount  = amount
        self.note    = note

    def run(self):
        with sqlite3.connect(DATABASE) as con:
            cur = con.cursor()
            res = cur.execute("SELECT name FROM clients WHERE id = ?", (self.hub_id,))
            hub_name = res.fetchone()[0]
            res = cur.execute("SELECT name FROM clients WHERE id = ?", (self.ep_id,))
            ep_name = res.fetchone()[0]
            res = cur.execute("SELECT name FROM books WHERE id = ?", (self.book_id,))
            book_name = res.fetchone()[0]
        TG_TOKEN = os.getenv('TG_TOKEN')
        CHAT_IDs = os.getenv('CHAT_ID').replace(' ', '').split(',')
        message  = f'Hub: {hub_name}\nEndpoint: {ep_name}\nBook: {book_name}\nAmount: {self.amount}\nNote: {self.note}'
        for chat_id in CHAT_IDs:
            os.system(f'curl -m 3 -X POST -H "Content-Type:multipart/form-data" -F chat_id={chat_id} -F text="{message}" "https://api.telegram.org/bot{TG_TOKEN}/sendMessage"')


@app.before_request
def before_request():
    ip = request.remote_addr
    con = getattr(g, '_connection', None)
    if con is None:
        con = g._connection = sqlite3.connect(DATABASE)
        con.row_factory = sqlite3.Row
    cur = con.cursor()
    res = cur.execute(f"SELECT id, name, master, hub FROM clients where ip = ? LIMIT 1", (ip,))
    row = res.fetchone()
    g.id, g.name, g.is_master, g.is_hub, g.hub_clients = None, None, None, None, None
    if row:
        g.id, g.name, g.is_master, g.is_hub = row
    if g.is_hub:
        hub_clients = cur.execute(f"SELECT id, name FROM clients WHERE id IN (SELECT client_id FROM hubs WHERE hub_id = ?)", (g.id,));
        hub_clients_dict = dict(hub_clients)
        g.hub_clients = hub_clients_dict


@app.teardown_appcontext
def after_request(exception):
    con = getattr(g, '_connection', None)
    if con is not None:
        con.commit()
        con.close()


@app.route("/")
def index():
    if not g.is_hub:
        return 'Forbidden!', 403
    return render_template("index.html", name=g.name, clients=g.hub_clients)

@app.route("/ep", methods=['GET', 'POST'])
def endpoint():
    ep_id = request.args.get('id')
    if ep_id and ep_id.isdecimal():
        ep_id = int(ep_id)
    else:
        return 'Bad request!', 400
    if ep_id not in g.hub_clients.keys():
        return 'Forbidden!', 403

    if request.method == 'GET':
        cur = g._connection.cursor()
        res = cur.execute("SELECT name, date FROM clients WHERE id = ? LIMIT 1", (ep_id,))
        row = res.fetchone()
        ep_name = row['name']
        ep_date = row['date']
        client_books = cur.execute(f"SELECT book_id, name, init_amount FROM client_books JOIN books ON client_books.book_id = books.id WHERE client_books.client_id = ?", (ep_id,))

        return render_template("allforms.html", name=g.name, clients=g.hub_clients, client_books=client_books, ep_name=ep_name, ep_date=ep_date)

    if request.method == 'POST':
        book_id = request.form['book_id']
        amount = request.form['amount']
        note = request.form['note']
        if book_id.isdecimal():
            book_id = int(book_id)
        else:
            return 'Bad request!', 400
        if not amount.isdecimal():
            return 'Bad request!', 400

        # Check book id
        cur = g._connection.cursor()
        client_books = cur.execute(f"SELECT book_id, name FROM client_books JOIN books ON client_books.book_id = books.id WHERE client_books.client_id = ?", (ep_id,))
        client_books = dict(client_books)
        if book_id not in client_books:
            return 'Forbidden!', 403

        # Add submission to DB
        cur = g._connection.cursor()
        cur.execute("INSERT INTO submissions (hub_id, client_id, book_id, amount, note) VALUES(?, ?, ?, ?, ?)", (g.id, ep_id, book_id, amount, note))
        submissions = cur.execute("SELECT date, amount FROM submissions WHERE hub_id = ? AND client_id = ? AND book_id = ? ORDER BY date DESC LIMIT 20", (g.id, ep_id, book_id))

        # Send TG info
        thread = TG_info(g.id, ep_id, book_id, amount, note)
        thread.start()

        return render_template("submit.html", name=g.name, clients=g.hub_clients, submissions=submissions, path=request.full_path)

if __name__ == '__main__':
    import bjoern

    bjoern.run(app, "0.0.0.0", 80)
